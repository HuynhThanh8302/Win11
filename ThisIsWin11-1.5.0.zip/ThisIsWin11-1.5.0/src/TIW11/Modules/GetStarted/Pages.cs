﻿namespace ThisIsWin11.GetStarted
{
    public enum PageTitle
    {
        GetStarted = 0,
        NewLook,
        StartMenu,
        Apps,
        Privacy,
        MicrosoftStore,
        ActionCenter,
        FileExplorer,
        SettingsApp,
        WindowsUpdates,
        SnapLayouts,
        Widgets,
        GestureControls,
        WallpapersNSounds,
        LockScreen,
        TouchKeyboard,
        AndroidApps,
        Gaming,
        Finish,
        Custom
    }
}